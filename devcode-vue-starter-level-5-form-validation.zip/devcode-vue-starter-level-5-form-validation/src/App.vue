<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="scss">
@import url("https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,500;0,700;1,300;1,500;1,700&display=swap");

#app {
  font-family: "Poppins", sans-serif;

  .router__btn {
    padding: 12px;
    background: aqua;
    color: #2c3e50;
    text-decoration-line: none;
    border-radius: 8px;
  }
}
</style>
